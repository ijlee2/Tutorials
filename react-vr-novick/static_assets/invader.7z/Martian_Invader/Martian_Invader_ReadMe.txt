=====
Info:
=====

Model description       : The evil Martian invader from "Mars Attacks!"
Author                  : Yasser Malaika

Mars Attacks is the property of the Topps Company, Inc. 
Mars Attacks logos and images (TM) & Copyright (c) of The Topps Co., Inc.
http://www.topps.com/

Mars Attacks! Movie and Movie images (TM) & Copyright (c) of Warner Brothers.

"Model by ymalaika"